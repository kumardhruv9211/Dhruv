package com.example.dhruv.cashrich;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Parcelable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import adapter.newsAdaptor;
import adapter.newsClickListner;
import constants.Constant;
import model.ExampleDTO;
import utils.Utils;
import volley.GsonRequest;
import volley.MyVolley;
import volley.RequestBuilder;

public class MainActivity extends AppCompatActivity implements newsClickListner.OnClickListener {
    private ProgressDialog progressbar;
    List<ExampleDTO.Article> exampleDTOList=new ArrayList<>();
    newsAdaptor newsadaptor;
    private RecyclerView listRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        progressbar = new ProgressDialog(MainActivity.this);
        progressbar.setMessage(getResources().getString(R.string.please_wait));
        progressbar.setCanceledOnTouchOutside(false);
        init();
    }
    private void init() {
        listRecyclerView = (RecyclerView)findViewById(R.id.my_recycler_view);
        //	listRecyclerView.setHasFixedSize(true);
        listRecyclerView
                .setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (Utils.checkNetwork(MainActivity.this)) {
            fetchNewsList();


        } else
        {
            Utils.showSnack(getWindow().getDecorView().findViewById(android.R.id.content),getResources().getString(R.string.no_network));
        }
    }
    private void fetchNewsList(){
        progressbar.show();
        GsonRequest<ExampleDTO> request = RequestBuilder.getNewDetaiils( "", ExampleDTO.class, null, (Response.Listener<ExampleDTO>) onSuccessListener(Constant.WEBCALL_CONSTANT.GET_NEWS_DATA), onErrorListener(Constant.WEBCALL_CONSTANT.GET_NEWS_DATA));
        request.setRetryPolicy(new DefaultRetryPolicy(30000, 4, 1.5f));
        MyVolley.getRequestQueue().add(request);
    }
    private Response.ErrorListener onErrorListener(int constant) {
        switch (constant) {
            case Constant.WEBCALL_CONSTANT.GET_NEWS_DATA:
                return new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                      progressbar.dismiss();
                        NetworkResponse response = error.networkResponse;
                        if(error.networkResponse!=null && error.networkResponse.statusCode==401 ) {


                        }
                    }
                };
        }
        return null;
    }

    private Response.Listener<?> onSuccessListener(int WEB_SERVICE_CONSTANT) {
        switch (WEB_SERVICE_CONSTANT)
        {
            case Constant.WEBCALL_CONSTANT.GET_NEWS_DATA:
                return new Response.Listener<ExampleDTO>() {
                    @Override
                    public void onResponse(ExampleDTO response) {
                        if(progressbar.isShowing()){
                           progressbar.dismiss();
                        }
                        try {
                            exampleDTOList = response.getArticles();
                            newsadaptor=new newsAdaptor(MainActivity.this,exampleDTOList,MainActivity.this);

                        } catch (Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }

                    }
                };


        }
        return  null;
    }

    @Override
    public void OnItemClick(View view, int position) throws UnsupportedEncodingException {

    }

    @Override
    public void OnItemClick(View view, int position, ExampleDTO.Article model) throws UnsupportedEncodingException {
        Intent i=new Intent(MainActivity.this, WebcallActivity.class);
        i.putExtra(Constant.INTENT_CONSTANT.INTENT_EMP_TEMP,model.getUrl());
        startActivity(i);
    }
}
