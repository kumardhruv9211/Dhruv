package constants;

import android.util.Log;

import com.example.dhruv.cashrich.BuildConfig;

//import com.tcs.platform.chroma.BuildConfig;

/**
 * Created by 1097461 on 2/12/2018.
 */

public class Constant {
    //for demo
  public final static String API_KEY="cf0d4c224043468eaa39cef7f2c05a78";
   public final static String BASE_URL = "https://newsapi.org/v2/top-headlines?sources=";

    private static final String TAG = "CHROMA LOG";



    public static void logger(String log) {
        if(BuildConfig.DEBUG)
        Log.i(TAG, log);
    }

    public static interface INTENT_CONSTANT {
        String INTENT_LEAVE_TYPE = "leavetype";
        String INTENT_GST_CONFIG= "gstConfig";
        String INTENT_EMP_TEMP = "teamDetail";

    }

    public static interface WEBCALL_CONSTANT {
        int GET_NEWS_DATA = 1;
        String INTENT_GST_CONFIG= "gstConfig";
        String INTENT_EMP_TEMP = "teamDetail";

    }

}
