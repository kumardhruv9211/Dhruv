package volley;

import com.android.volley.Request;
import com.android.volley.Response;

import java.util.Map;

import constants.Constant;
import model.ExampleDTO;

/**
 * Created by Dhruv on 08-04-2019.
 */
public  class RequestBuilder {



    public static GsonRequest<ExampleDTO> getNewDetaiils(String source, Class<ExampleDTO> clazz, Map<String, String> headers,
                                                            Response.Listener<ExampleDTO> listener, Response.ErrorListener errorListener)
    {
        String url =Constant.BASE_URL+source+"&apiKey="+Constant.API_KEY;
        Constant.logger("tiles  url "+url);
        GsonRequest<ExampleDTO> gsonRequest=new GsonRequest<ExampleDTO>(url, Request.Method.GET,clazz,headers,listener,errorListener);
        return  gsonRequest;
    }

}
