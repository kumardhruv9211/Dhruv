package volley;

/**
 * Created by 1097461 on 7/19/2017.
 */

import android.app.ActivityManager;
import android.content.Context;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import utils.LruBitmapCache;

/**
 * Helper class that is used to provide references to initialized RequestQueue(chromauat3nov) and ImageLoader(chromauat3nov)
 *
 * @author Ognyan Bankov
 *
 */
public class MyVolley {
    private static RequestQueue mRequestQueue;
    private static ImageLoader mImageLoader;
    private static final String TAG=null;
    private MyVolley() {
        // no instances
    }


    public static void init(Context context) {
      /*  try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");

            // Generate the certificate using the certificate file under res/raw/cert.cer
            InputStream caInput = new BufferedInputStream(context.getResources().openRawResource(R.raw.chromauat3nov));
            Certificate ca = cf.generateCertificate(caInput);
            caInput.close();

            // Create a KeyStore containing our trusted CAs
            String keyStoreType = KeyStore.getDefaultType();
            KeyStore trusted = null;

            trusted = KeyStore.getInstance(keyStoreType);

            trusted.load(null, null);
            trusted.setCertificateEntry("ca", ca);

            // Create a TrustManager that trusts the CAs in our KeyStore
            String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
            tmf.init(trusted);

            // Create an SSLContext that uses our TrustManager
            SSLContext mContext = SSLContext.getInstance("TLS");
            mContext.init(null, tmf.getTrustManagers(), null);
            SSLSocketFactory sf = mContext.getSocketFactory();
            if(mRequestQueue==null)
                mRequestQueue = Volley.newRequestQueue(context.getApplicationContext(), new HurlStack(null, sf));
            // mRequestQueue = Volley.newRequestQueue(context,new HurlStack(null, pinnedSSLSocketFactory()));
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }*/
      if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(context);

        }
        int memClass = ((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE))
                .getMemoryClass();
        // Use 1/8th of the available memory for this memory cache.
        int cacheSize = 1024 * 1024 * memClass / 8;
        mImageLoader = new ImageLoader(mRequestQueue, new LruBitmapCache(cacheSize));
    }
  /*  private static SSLSocketFactory pinnedSSLSocketFactory() {
        try {
            return new TLSSocketFactory("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArHuAqjwwKh55x2VNci93" +
                    "QnDz0pPHvRr925g+7qyhlCgKYHUIj6vIM2k63cXCbRi1Iv9S5lE9KwFu/r8a425o" +
                    "E/iIASuNke5DXusbiQ2k9smDi7TMsKLVv5jh/5gQU0SbRfzrKYW4oPcdhG+aXK42" +
                    "bRajRN+Ocj1r8ZRx0NSWuFV41MWEu5UD+WxX2oE69d3B12hGmUqg3cn/9YWcELG8" +
                    "U7SSqK8ujlxa80KJRsrXLb7Rml53wGTKVv0oCDOjTEnPKC/BQKGUl2xVPbArtoPi" +
                    "tXLDSl1vJvoBe2i1U0I2yzqrlum+UzmmxLCCQXZyoOX31ZurtCgg7ylqJs8Sjepp" +
                    "3wIDAQAB");
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }*/


 /*   public <T> void addToRequestQueue(Request<T> req,String tag)
    {
        req.setTag(TextUtils.isEmpty(TAG)?TAG:tag);
        req.setRetryPolicy(new DefaultRetryPolicy(60000,2,1.5f));
        req
    }*/


    public static RequestQueue getRequestQueue() {
        if (mRequestQueue != null) {
            return mRequestQueue;
        } else {
            throw new IllegalStateException("RequestQueue not initialized");
        }
    }


    /**
     * Returns instance of ImageLoader initialized with {@see FakeImageCache} which effectively means
     * that no memory caching is used. This is useful for images that you know that will be show
     * only once.
     *
     * @return
     */
    public static ImageLoader getImageLoader() {
        if (mImageLoader != null) {
            return mImageLoader;
        } else {
            throw new IllegalStateException("ImageLoader not initialized");
        }
    }
}
