package adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.dhruv.cashrich.R;

import java.io.UnsupportedEncodingException;

/**
 * Created by Dhruv on 08-04-2019.
 */
public class news_view_holder extends RecyclerView.ViewHolder implements
        View.OnClickListener {

    public ImageView url_img;
    public TextView tv_heading,tv_desc,tv_time;
    LinearLayout lyt_container;


    private newsClickListner.OnClickListener onClickListener;
    public news_view_holder(View itemView) {
        super(itemView);
        this.url_img=(ImageView) itemView.findViewById(R.id.url_img);
        this.tv_heading = (TextView) itemView.findViewById(R.id.tv_heading);
        this.tv_desc = (TextView) itemView.findViewById(R.id.tv_desc);
        this.tv_time = (TextView) itemView.findViewById(R.id.tv_time);
        this.lyt_container=(LinearLayout)itemView.findViewById(R.id.lyt_container);

    }

    @Override
    public void onClick(View v) {
        if (onClickListener != null) {
            try {
                onClickListener.OnItemClick(v, getPosition());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }

    }
    public void setClickListener(newsClickListner.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
}
