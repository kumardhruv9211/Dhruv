package adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.dhruv.cashrich.R;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import constants.Constant;
import model.ExampleDTO;
import utils.ImageLoader;

/**
 * Created by Dhruv on 08-04-2019.
 */
public class newsAdaptor  extends RecyclerView.Adapter<news_view_holder> {



    List<ExampleDTO.Article> exampleDTOList;

    private Context context;
    ImageLoader imageLoader;
    newsClickListner.OnClickListener clickListener;
    public newsAdaptor(Context context,List<ExampleDTO.Article> dataSet1,newsClickListner.OnClickListener onClickListener) {
        this.context = context;
        this.exampleDTOList = dataSet1;
        this.clickListener=onClickListener;
        this.notifyDataSetChanged();

    }

    @NonNull
    @Override
    public news_view_holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater mInflater = LayoutInflater.from(viewGroup.getContext());

        ViewGroup mainGroup = (ViewGroup) mInflater.inflate(
                R.layout.card_view_item, viewGroup, false);
        news_view_holder listHolder = new news_view_holder(mainGroup);
        listHolder.setClickListener(clickListener);
        return listHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull news_view_holder holder,final int listPosition) {
        news_view_holder mainHolder = (news_view_holder) holder;
        imageLoader = new ImageLoader(context);
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("dd-MM-yyyy hh:mm");

       /* Calendar calendar3=Calendar.getInstance();
        String day3,month3,yr3;
        try {
            calendar3.setTime(simpleDateFormat3.parse(claimrequestlistdata.get(listPosition).getStartDate()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        day3=calendar3.get(Calendar.DAY_OF_MONTH)+"";
        month3=context.getResources().getStringArray(R.array.months)[calendar3.get(Calendar.MONTH)];
        yr3=calendar3.get(Calendar.YEAR)+"";
        SpannableString date3=new SpannableString(day3+" "+month3+" "+yr3+" ");*/

        imageLoader.DisplayImage(exampleDTOList.get(listPosition).getUrl(), mainHolder.url_img);
        mainHolder.tv_heading.setText(exampleDTOList.get(listPosition).getTitle());
        mainHolder.tv_desc.setText(exampleDTOList.get(listPosition).getDescription());
        mainHolder.tv_time.setText(exampleDTOList.get(listPosition).getPublishedAt());
        mainHolder.lyt_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    clickListener.OnItemClick(v,listPosition,exampleDTOList.get(listPosition));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null != exampleDTOList ? exampleDTOList.size() : 0);

    }
}

