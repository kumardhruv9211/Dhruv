package adapter;

import android.view.View;

import java.io.UnsupportedEncodingException;

import model.ExampleDTO;

/**
 * Created by Dhruv on 08-04-2019.
 */
public class newsClickListner {
    public interface OnClickListener {
        public void OnItemClick(View view, int position) throws UnsupportedEncodingException;

        public void OnItemClick(View view, int position,  ExampleDTO.Article model) throws UnsupportedEncodingException;


    }
}
